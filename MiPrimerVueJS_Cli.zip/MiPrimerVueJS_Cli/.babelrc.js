module.exports = {
    presets: ['@babel/present-env']
}