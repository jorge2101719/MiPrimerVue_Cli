<template>
    <div id="app">
        {{titular}}
            <table class="table">
        <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>RUN</th>
                <th>Nacimiento</th>
                <th>Edad</th>
            </tr>
            <tr v-for="(dato, index) in lista" :key="index">
                <td>{{dato.id}}</td>
                <td>{{dato.nombre}}</td>
                <td>{{dato.apellido}}</td>
                <td>{{dato.run}}</td>
                <td>{{dato.nacimiento}}</td>
                <td>{{dato.edad}}</td>
            </tr>
        </table>
    </div>
</template>

<script>
export default {
    name: "App",
    data(){
        return{
            titular: 'Mi Primer Vue-Cli',
            dato: '',
            lista: [{
                        id: '1',
                        nombre: 'Yasna',
                        apellido: 'Yukovich',
                        run: '13.493.757-K',
                        nacimiento: '05-06-1985',
                        edad: '36'
                    },
                    {
                        id: '2',
                        nombre: 'Ximena',
                        apellido: 'Miramar',
                        run: '21.984.253-1',
                        nacimiento: '30-11-2003',
                        edad: '17'
                    },
                    {
                        id: '3',
                        nombre: 'Felipe',
                        apellido: 'González',
                        run: '16.958.743-2',
                        nacimiento: '24-02-1996',
                        edad: '25'
                    },
                    {
                        id: '4',
                        nombre: 'José',
                        apellido: 'Pérez',
                        run: '09.123.456-2',
                        nacimiento: '12-04-1967',
                        edad: '52'
                    }
                ]
        }
    },
}
</script>